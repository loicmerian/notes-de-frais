export const initAuth = async () => ({ username: 'loic.merian@elidia.fr' });
export const getAccount = () => ({ username: 'loic.merian@elidia.fr' });
export const login = () => {}; export const logout = () => {}; export const getToken = async () => 't';
