const fs = new Map(); window.__fs = fs; window.__mails = [];
export async function getJson(p){ const b=fs.get(p); return b? JSON.parse(await b.text()):null; }
export async function downloadFile(p){ if(!fs.has(p)){const e=new Error('404');e.status=404;throw e;} return fs.get(p); }
export async function getWebUrl(p){ return 'about:blank'; }
export async function uploadFile(p,b,t){ if(!(b instanceof Blob)) b=new Blob([b],{type:t}); fs.set(p,b); return {}; }
export async function putJson(p,d){ return uploadFile(p,new Blob([JSON.stringify(d)],{type:'application/json'})); }
export async function deleteFile(p){ fs.delete(p); }
export async function listChildren(p){ return [...fs.keys()].filter(k=>k.startsWith(p+'/')&&!k.slice(p.length+1).includes('/')).map(k=>({name:k.slice(p.length+1),file:{}})); }
export async function me(){ return {}; }
export async function sendMail(m){ window.__mails.push(m); }
