import fs from 'fs';
import { remplirModele } from '../src/excel.js';
const modele = fs.readFileSync('public/modele.xlsx');
const depenses = [
 {date:'2026-11-11',nature:'Eurostar - Paris-Londres',ttc:228,tva:0,categorie:'sncf'},
 {date:'2026-11-09',nature:'Déjeuner - Le Procope',ttc:50.7,tva:4.61,categorie:'restaurant',invite:'Laurent Gay'},
 {date:'2026-11-03',nature:'Déplacement Toulouse (2 × 215 km × 0,18 €)',ttc:77.4,tva:0,categorie:'divers'},
 {date:'2026-11-03',nature:'Parking Toulouse',ttc:14.5,tva:2.42,categorie:'parking'},
 {date:'2026-11-05',nature:'Taxi G7',ttc:21.5,tva:0,categorie:'taxi'},
 {date:'2026-11-06',nature:'Hôtel Ibis & co <test>',ttc:130.95,tva:0,categorie:'hotel'},
];
const out = await remplirModele(modele,{mois:'2026-11',societe:'Elidia',nom:'Merian',prenom:'Loïc',dateSignature:'2026-12-01',depenses});
fs.writeFileSync('test/out.xlsx', out);
console.log('ok', out.length);
