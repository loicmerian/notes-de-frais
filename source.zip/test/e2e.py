import json, base64, sys
from playwright.sync_api import sync_playwright
reponses = [
 {"date":"2026-11-12","fournisseur":"Le Procope","objet":"déjeuner","montant_ttc":50.7,"montant_tva":4.61,"devise":"EUR","categorie":"restaurant","remarque":""},
 {"date":"2026-11-20","fournisseur":"Eurostar","objet":"Paris-Londres","montant_ttc":228,"montant_tva":0,"devise":"GBP","categorie":"sncf","remarque":""},
]
calls=[]
def claude(route):
    body=json.loads(route.request.post_data); calls.append([c['type'] for c in body['messages'][0]['content']])
    r=reponses[len(calls)-1]
    route.fulfill(status=200, headers={'access-control-allow-origin':'*','content-type':'application/json'},
      body=json.dumps({"content":[{"type":"tool_use","id":"x","name":"enregistrer_depense","input":r}]}))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(**p.devices['Pixel 7'])
    pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.on('console',lambda m: m.type=='error' and errs.append(m.text))
    pg.route('https://api.anthropic.com/**', claude)
    pg.add_init_script("localStorage.setItem('ndf-reglages', JSON.stringify({apiKey:'sk-test'}))")
    pg.goto('http://localhost:8765/notes-de-frais/'); pg.wait_for_selector('#ecran-mois:not([hidden])')
    pg.screenshot(path='s1.png')
    # scan
    pg.set_input_files('#in-photo','ticket.jpg'); pg.wait_for_selector('#dlg-pages[open]')
    pg.set_input_files('#in-page','ticket.jpg'); pg.wait_for_function("document.querySelectorAll('#pages figure').length==2")
    pg.screenshot(path='s2.png')
    pg.click('#pages-ok'); pg.wait_for_selector('#dlg-depense[open]')
    pg.fill('[name=invite]','Laurent Gay'); pg.screenshot(path='s3.png')
    pg.click('#form-depense [type=submit]'); pg.wait_for_function("!document.querySelector('#dlg-depense').open")
    # OneDrive renvoie une version périmée (sans la 1re dépense) : elle ne doit pas être perdue
    pg.evaluate("""(()=>{const k=[...window.__fs.keys()].find(k=>k.endsWith('_ndf-donnees.json'));window.__fs.set(k,new Blob([JSON.stringify({mois:'2026-11',statut:'ouvert',depenses:[],modifie:'2000-01-01'})]));document.dispatchEvent(new Event('visibilitychange'))})()""")
    pg.wait_for_timeout(800)
    # import pdf
    pg.set_input_files('#in-fichier','facture.pdf'); pg.wait_for_selector('#dlg-depense[open]')
    pg.screenshot(path='s4.png')
    pg.fill('[name=ttc]','265,40'); pg.click('#form-depense [type=submit]'); pg.wait_for_function("!document.querySelector('#dlg-depense').open")
    # km
    pg.click('#btn-manuel'); pg.click('#manuel-km'); pg.wait_for_selector('#dlg-km[open]')
    pg.fill('#form-km [name=objet]','Toulouse, Mme Acutis'); pg.fill('#form-km [name=km]','215')
    pg.screenshot(path='s5.png'); pg.click('#form-km [type=submit]'); pg.wait_for_function("!document.querySelector('#dlg-km').open")
    pg.wait_for_timeout(500); pg.screenshot(path='s6.png')
    nb=pg.evaluate("JSON.parse('0')") 
    pg.evaluate("""(async()=>{const k=[...window.__fs.keys()].find(k=>k.endsWith('_ndf-donnees.json'));return JSON.parse(await window.__fs.get(k).text()).depenses.length})()""")
    print('depenses apres km', pg.evaluate("""(async()=>{const k=[...window.__fs.keys()].find(k=>k.endsWith('_ndf-donnees.json'));return JSON.parse(await window.__fs.get(k).text()).depenses.map(d=>d.fournisseur)})()"""))
    # justificatif orphelin : on retire la ligne du Procope du JSON puis on recharge l'affichage
    pg.evaluate("""(async()=>{const k=[...window.__fs.keys()].find(k=>k.endsWith('_ndf-donnees.json'));const d=JSON.parse(await window.__fs.get(k).text());d.depenses=d.depenses.filter(x=>x.fournisseur!=='Le Procope');d.modifie='2999-01-01';window.__fs.set(k,new Blob([JSON.stringify(d)]));})()""")
    pg.click('#btn-reglages'); pg.click('#form-reglages [type=submit]'); pg.wait_for_timeout(1000)
    print('orphelins visibles', pg.is_visible('#bloc-orphelins'), pg.inner_text('#orphelins'))
    pg.screenshot(path='s9.png')
    reponses.append(reponses[0])
    pg.click('#orphelins li'); pg.wait_for_selector('#dlg-depense[open]')
    pg.fill('[name=invite]','Laurent Gay'); pg.click('#form-depense [type=submit]'); pg.wait_for_function("!document.querySelector('#dlg-depense').open")
    pg.wait_for_timeout(500)
    print('orphelins apres', pg.is_visible('#bloc-orphelins'), pg.inner_text('#total-nb'))
    # cloture
    pg.click('#btn-cloturer'); pg.wait_for_selector('#dlg-cloture[open]'); pg.screenshot(path='s7.png')
    pg.click('#clo-ok'); pg.wait_for_function("!document.querySelector('#dlg-cloture').open", timeout=20000)
    pg.wait_for_timeout(500); pg.screenshot(path='s8.png')
    mails=pg.evaluate("window.__mails.map(m=>({to:m.to,cc:m.cc,subject:m.subject,html:m.html,att:m.attachments.map(a=>[a.name,a.blob.size])}))")
    files=pg.evaluate("[...window.__fs.keys()]")
    x=pg.evaluate("(async()=>{const m=window.__mails[0];const r=[];for(const a of m.attachments){const b=new Uint8Array(await a.blob.arrayBuffer());let s='';for(let i=0;i<b.length;i+=0x8000)s+=String.fromCharCode(...b.subarray(i,i+0x8000));r.push(btoa(s));}return r})()")
    open('mail.xlsx','wb').write(base64.b64decode(x[0])); open('mail.zip','wb').write(base64.b64decode(x[1]))
    print('calls',calls); print('mails',json.dumps(mails,ensure_ascii=False,indent=1)); print('files',json.dumps(files,ensure_ascii=False,indent=1)); print('errs',errs)
    b.close()
