from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_context(**p.devices['Pixel 7']).new_page()
    pg.goto('http://localhost:8765/notes-de-frais/'); pg.wait_for_selector('#ecran-mois:not([hidden])')
    pg.click('#btn-manuel'); pg.click('#manuel-autre'); pg.wait_for_selector('#dlg-depense[open]')
    for c in ['restaurant','taxi']:
        pg.select_option('[name=categorie]',c); print(c,'invite visible:',pg.is_visible('#lbl-invite'))
    pg.click('#dep-annuler'); pg.click('#btn-reglages')
    print('reglages restaurant',pg.is_checked('[name=inviteRestaurant]'),'taxi',pg.is_checked('[name=inviteTaxi]'))
    pg.check('[name=inviteTaxi]'); pg.click('#form-reglages [type=submit]'); pg.wait_for_timeout(500)
    pg.click('#btn-manuel'); pg.click('#manuel-autre'); pg.wait_for_selector('#dlg-depense[open]')
    pg.select_option('[name=categorie]','taxi'); print('taxi apres activation:',pg.is_visible('#lbl-invite'))
    pg.screenshot(path='s10.png'); b.close()
