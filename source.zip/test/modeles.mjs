import fs from 'fs'; import JSZip from 'jszip'; import { remplirModele } from '../src/excel.js';
const src = fs.readFileSync('/mnt/user-data/uploads/a29fc697-ndf_merian_octobre_2025.xlsx');
const vide = { mois:'2026-11', societe:'Elidia', nom:'', prenom:'', dateSignature:'2026-11-25', depenses:[] };
// Modèle personnel (avec signature) pour OneDrive
const perso = await remplirModele(src, { ...vide, nom:'Merian', prenom:'Loïc' });
fs.writeFileSync('test/modele-perso.xlsx', perso);
// Modèle public (sans signature, sans chemin local)
const z = await JSZip.loadAsync(await remplirModele(src, vide));
let sh = await z.file('xl/worksheets/sheet1.xml').async('string');
const rels = await z.file('xl/worksheets/_rels/sheet1.xml.rels').async('string');
const rid = sh.match(/<drawing r:id="([^"]+)"\/>/)[1];
sh = sh.replace(/<drawing r:id="[^"]+"\/>/, '');
z.file('xl/worksheets/sheet1.xml', sh);
z.file('xl/worksheets/_rels/sheet1.xml.rels', rels.replace(new RegExp(`<Relationship [^>]*Id="${rid}"[^>]*/>`), ''));
for (const f of ['xl/drawings/drawing2.xml','xl/drawings/_rels/drawing2.xml.rels','xl/media/image1.jpg']) z.remove(f);
let ct = await z.file('[Content_Types].xml').async('string');
z.file('[Content_Types].xml', ct.replace(/<Override PartName="\/xl\/drawings\/drawing2.xml"[^>]*\/>/, ''));
let wb = await z.file('xl/workbook.xml').async('string');
z.file('xl/workbook.xml', wb.replace(/<mc:AlternateContent[\s\S]*?<\/mc:AlternateContent>/, ''));
fs.writeFileSync('public/modele.xlsx', await z.generateAsync({ type:'uint8array', compression:'DEFLATE' }));
console.log('ok');
