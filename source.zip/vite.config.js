import { defineConfig } from 'vite';
import path from 'path';
export default defineConfig(({ mode }) => ({
  base: '/notes-de-frais/',
  build: { outDir: mode === 'test' ? 'test/dist' : 'dist', assetsDir: '', chunkSizeWarningLimit: 2000 },
  plugins: mode === 'test' ? [{
    name: 'mocks',
    enforce: 'pre',
    resolveId(src, importer) {
      if (importer && importer.includes('/src/') && /\.\/(auth|graph)\.js$/.test(src))
        return path.resolve('test/mocks', path.basename(src));
    },
  }] : [],
}));
