import { PublicClientApplication, InteractionRequiredAuthError } from '@azure/msal-browser';

export const CLIENT_ID = '32c4b64c-19d3-4513-a296-c3417695554d';
export const TENANT_ID = '9317ff20-9568-4e21-b7b2-363beda5a6fc';
const SCOPES = ['User.Read', 'Files.ReadWrite', 'Mail.Send'];

const redirectUri = new URL(import.meta.env.BASE_URL, location.origin).href;

const pca = new PublicClientApplication({
  auth: {
    clientId: CLIENT_ID,
    authority: `https://login.microsoftonline.com/${TENANT_ID}`,
    redirectUri,
    postLogoutRedirectUri: redirectUri,
  },
  cache: { cacheLocation: 'localStorage' },
});

let ready;
export function initAuth() {
  ready ||= (async () => {
    await pca.initialize();
    const res = await pca.handleRedirectPromise();
    if (res?.account) pca.setActiveAccount(res.account);
    if (!pca.getActiveAccount()) {
      const all = pca.getAllAccounts();
      if (all.length) pca.setActiveAccount(all[0]);
    }
    return pca.getActiveAccount();
  })();
  return ready;
}

export const getAccount = () => pca.getActiveAccount();

export function login() {
  return pca.loginRedirect({ scopes: SCOPES, prompt: 'select_account' });
}

export function logout() {
  return pca.logoutRedirect({ account: pca.getActiveAccount() });
}

export async function getToken() {
  await initAuth();
  const account = pca.getActiveAccount();
  if (!account) {
    await login();
    throw new Error('Connexion en cours…');
  }
  try {
    const r = await pca.acquireTokenSilent({ scopes: SCOPES, account });
    return r.accessToken;
  } catch (e) {
    if (e instanceof InteractionRequiredAuthError) {
      await pca.acquireTokenRedirect({ scopes: SCOPES, account });
      throw new Error('Reconnexion en cours…');
    }
    throw e;
  }
}
