import './style.css';
import JSZip from 'jszip';
import { initAuth, login, logout, getAccount } from './auth.js';
import * as graph from './graph.js';
import * as store from './store.js';
import { CATEGORIES, remplirModele, trierDepenses } from './excel.js';
import { lireJustificatif } from './claude.js';
import { photoToJpeg, jpegsToPdf, blobToBase64 } from './scan.js';

const $ = (s) => document.querySelector(s);
const euros = (n) => (Number(n) || 0).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' });
const num = (s) => {
  const v = parseFloat(String(s ?? '').replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(v) ? Math.round(v * 100) / 100 : 0;
};
const aujourdhui = () => new Date().toISOString().slice(0, 10);
const fmtDate = (iso) => iso.split('-').reverse().join('/');

let moisAffiche = store.moisCourant();
let donnees = null;

// ---------- utilitaires d'interface ----------
function attente(texte) {
  $('#attente-texte').textContent = texte || 'Un instant…';
  $('#attente').hidden = !texte;
}
let toastTimer;
function toast(msg, erreur = false) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (erreur ? ' erreur' : '');
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), erreur ? 7000 : 3500);
}
async function protege(fn) {
  try {
    return await fn();
  } catch (e) {
    console.error(e);
    attente(null);
    toast(e.message || String(e), true);
  }
}

// ---------- affichage du mois ----------
async function afficherMois(force = false) {
  $('#mois-libelle').textContent = store.libelleMois(moisAffiche);
  $('#mois-suiv').disabled = moisAffiche >= store.moisCourant();
  attente('Chargement…');
  donnees = await store.chargerMois(moisAffiche, force);
  attente(null);
  rendreListe();
}

function rendreListe() {
  const clos = donnees.statut === 'clos';
  $('#mois-statut').textContent = clos ? 'Clôturé' : 'En cours';
  $('#mois-statut').className = 'statut ' + (clos ? 'clos' : 'ouvert');
  const deps = trierDepenses(donnees.depenses);
  $('#total-ttc').textContent = euros(deps.reduce((s, d) => s + d.ttc, 0));
  $('#total-nb').textContent = deps.length;
  $('#liste-vide').hidden = deps.length > 0;
  const ul = $('#liste');
  ul.innerHTML = '';
  for (const d of deps) {
    const li = document.createElement('li');
    li.innerHTML = `
      <div class="l-date">${fmtDate(d.date).slice(0, 5)}</div>
      <div class="l-texte"><div class="l-nature"></div><div class="l-cat petit"></div></div>
      <div class="l-montant">${euros(d.ttc)}</div>`;
    li.querySelector('.l-nature').textContent = store.nature(d);
    li.querySelector('.l-cat').textContent =
      CATEGORIES[d.categorie]?.label + (d.invite ? ` · ${d.invite}` : '') + (d.fichier ? '' : ' · sans justificatif');
    li.onclick = () => protege(() => ouvrirDepense({ ...d }, { existante: true }));
    ul.appendChild(li);
  }
  const bandeau = $('#bandeau-clos');
  bandeau.hidden = !clos;
  if (clos) bandeau.textContent = `Envoyé à ${donnees.envoye_a || 'ton comptable'} le ${fmtDate((donnees.clos_le || '').slice(0, 10))}.`;
  $('#btn-cloturer').hidden = clos;
  $('#btn-rouvrir').hidden = !clos;
  $('#btn-excel').hidden = deps.length === 0;
}

/** Mois ouverts proposés pour l'affectation : mois de la dépense, mois précédent et mois courant. */
async function moisOuverts(dateIso) {
  const candidats = new Set([store.moisCourant(), store.decalerMois(store.moisCourant(), -1)]);
  if (dateIso) candidats.add(dateIso.slice(0, 7));
  if (donnees) candidats.add(donnees.mois);
  const liste = [...candidats].filter((m) => m <= store.moisCourant()).sort().reverse();
  const res = [];
  for (const m of liste) {
    const d = await store.chargerMois(m);
    if (d.statut !== 'clos') res.push(m);
  }
  return res;
}

async function remplirAffectation(select, dateIso, choix) {
  const ouverts = await moisOuverts(dateIso);
  select.innerHTML = ouverts.map((m) => `<option value="${m}">${store.libelleMois(m)}</option>`).join('');
  const prefere = choix || (dateIso && ouverts.includes(dateIso.slice(0, 7)) ? dateIso.slice(0, 7) : ouverts.includes(moisAffiche) ? moisAffiche : ouverts[0]);
  select.value = prefere;
  if (!ouverts.length) throw new Error('Aucun mois ouvert : rouvre un mois pour ajouter une dépense.');
}

// ---------- formulaire dépense ----------
const dlgDep = $('#dlg-depense');
const formDep = $('#form-depense');
formDep.categorie.innerHTML = Object.entries(CATEGORIES)
  .map(([k, v]) => `<option value="${k}">${v.label}</option>`)
  .join('');
function majInvite() {
  $('#lbl-invite').hidden = !CATEGORIES[formDep.categorie.value]?.invite;
}
formDep.categorie.onchange = majInvite;

/**
 * Ouvre le formulaire. Résout avec la dépense enregistrée, ou null si annulé.
 * @param {object} dep
 * @param {{existante?:boolean, fichier?:{blob:Blob, ext:string}, apercu?:string, alerte?:string, titre?:string}} opt
 */
function ouvrirDepense(dep, opt = {}) {
  return new Promise(async (resolve) => {
    $('#dep-titre').textContent = opt.titre || (opt.existante ? 'Modifier la dépense' : 'Nouvelle dépense');
    const ap = $('#dep-apercu');
    ap.innerHTML = '';
    if (opt.apercu) ap.innerHTML = `<img src="${opt.apercu}" alt="Justificatif" />`;
    else if (opt.fichier) ap.innerHTML = `<p class="petit">Justificatif PDF joint</p>`;
    if (opt.existante && dep.fichier) {
      const a = document.createElement('button');
      a.type = 'button';
      a.className = 'lien';
      a.textContent = 'Voir le justificatif';
      a.onclick = () =>
        protege(async () => {
          const w = window.open('', '_blank');
          const url = await graph.getWebUrl(`${store.dossierMois(donnees.mois)}/${dep.fichier}`);
          if (w) w.location = url;
          else location.href = url;
        });
      ap.appendChild(a);
    }
    const al = $('#dep-alerte');
    al.hidden = !opt.alerte;
    al.textContent = opt.alerte || '';

    formDep.date.value = dep.date || aujourdhui();
    formDep.categorie.value = dep.categorie || 'divers';
    formDep.fournisseur.value = dep.fournisseur || '';
    formDep.objet.value = dep.objet || '';
    formDep.ttc.value = dep.ttc ? String(dep.ttc).replace('.', ',') : '';
    formDep.tva.value = dep.tva ? String(dep.tva).replace('.', ',') : '';
    formDep.invite.value = dep.invite || '';
    majInvite();
    const clos = opt.existante && donnees.statut === 'clos';
    $('#lbl-affectation').hidden = !!opt.existante;
    if (!opt.existante) await remplirAffectation(formDep.affectation, formDep.date.value);
    formDep.date.onchange = () => !opt.existante && remplirAffectation(formDep.affectation, formDep.date.value);
    $('#dep-supprimer').hidden = !opt.existante || clos;
    formDep.querySelector('[type=submit]').hidden = clos;
    [...formDep.elements].forEach((el) => el.tagName !== 'BUTTON' && (el.disabled = clos));

    const fermer = (val) => {
      dlgDep.close();
      formDep.onsubmit = $('#dep-annuler').onclick = $('#dep-supprimer').onclick = null;
      resolve(val);
    };
    $('#dep-annuler').onclick = () => fermer(null);
    dlgDep.oncancel = () => fermer(null);
    $('#dep-supprimer').onclick = () =>
      protege(async () => {
        if (!confirm('Supprimer cette dépense et son justificatif ?')) return;
        attente('Suppression…');
        if (dep.fichier) await graph.deleteFile(`${store.dossierMois(donnees.mois)}/${dep.fichier}`);
        donnees.depenses = donnees.depenses.filter((x) => x.id !== dep.id);
        await store.sauverMois(donnees);
        attente(null);
        rendreListe();
        fermer(null);
        toast('Dépense supprimée');
      });
    formDep.onsubmit = (ev) => {
      ev.preventDefault();
      protege(async () => {
        const ttc = num(formDep.ttc.value);
        const tva = num(formDep.tva.value);
        if (ttc <= 0) throw new Error('Indique le montant TTC.');
        if (tva > ttc) throw new Error('La TVA ne peut pas dépasser le TTC.');
        const cat = formDep.categorie.value;
        const maj = {
          ...dep,
          id: dep.id || store.nouvelId(),
          cree: dep.cree || Date.now(),
          date: formDep.date.value,
          categorie: cat,
          fournisseur: formDep.fournisseur.value.trim(),
          objet: formDep.objet.value.trim(),
          ttc,
          tva,
          invite: CATEGORIES[cat].invite ? formDep.invite.value.trim() : '',
        };
        maj.nature = store.nature(maj);
        attente('Enregistrement dans OneDrive…');
        const mois = opt.existante ? donnees.mois : formDep.affectation.value;
        const cible = await store.chargerMois(mois);
        if (cible.statut === 'clos') throw new Error(`${store.libelleMois(mois)} est clôturé.`);
        if (opt.fichier && !maj.fichier) {
          maj.fichier = store.nomJustificatif(maj, opt.fichier.ext);
          await graph.uploadFile(`${store.dossierMois(mois)}/${maj.fichier}`, opt.fichier.blob, opt.fichier.blob.type || 'application/pdf');
        }
        const i = cible.depenses.findIndex((x) => x.id === maj.id);
        if (i >= 0) cible.depenses[i] = maj;
        else cible.depenses.push(maj);
        await store.sauverMois(cible);
        attente(null);
        if (mois !== moisAffiche) {
          moisAffiche = mois;
          await afficherMois();
        } else {
          donnees = cible;
          rendreListe();
        }
        toast(`Enregistré dans ${store.libelleMois(mois)}`);
        fermer(maj);
      });
    };
    dlgDep.showModal();
  });
}

/** Lit le justificatif avec Claude ; en cas d'échec, renvoie un formulaire vide avec un message. */
async function lire(source) {
  const r = store.reglages();
  if (!r.apiKey) return { dep: {}, alerte: 'Lecture automatique désactivée : ajoute ta clé API Claude dans les réglages.' };
  attente('Lecture du justificatif…');
  try {
    const x = await lireJustificatif(source, r);
    const alertes = [];
    if (x.devise && x.devise !== 'EUR') alertes.push(`Montant lu en ${x.devise} : saisis le montant en euros débité sur ton compte.`);
    if (x.remarque) alertes.push(x.remarque);
    return {
      dep: {
        date: /^\d{4}-\d{2}-\d{2}$/.test(x.date) ? x.date : aujourdhui(),
        fournisseur: x.fournisseur,
        objet: x.objet,
        ttc: x.montant_ttc,
        tva: x.montant_tva,
        categorie: CATEGORIES[x.categorie] ? x.categorie : 'divers',
      },
      alerte: alertes.join(' '),
    };
  } catch (e) {
    return { dep: {}, alerte: e.message };
  } finally {
    attente(null);
  }
}

// ---------- scan photo (multi-pages) ----------
let pages = [];
function rendrePages() {
  $('#pages').innerHTML = pages.map((p, i) => `<figure><img src="${p.dataUrl}" /><figcaption>Page ${i + 1}</figcaption></figure>`).join('');
}
async function ajouterPhoto(file) {
  attente('Préparation de la photo…');
  pages.push(await photoToJpeg(file));
  attente(null);
  rendrePages();
  if (!$('#dlg-pages').open) $('#dlg-pages').showModal();
}
$('#in-photo').onchange = (e) =>
  protege(async () => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f) return;
    pages = [];
    await ajouterPhoto(f);
  });
$('#in-page').onchange = (e) =>
  protege(async () => {
    const f = e.target.files[0];
    e.target.value = '';
    if (f) await ajouterPhoto(f);
  });
$('#pages-annuler').onclick = () => {
  pages = [];
  $('#dlg-pages').close();
};
$('#pages-ok').onclick = () =>
  protege(async () => {
    $('#dlg-pages').close();
    const pp = pages;
    pages = [];
    const { dep, alerte } = await lire({ images: pp.map((p) => p.base64) });
    const blob = jpegsToPdf(pp);
    await ouvrirDepense(dep, { fichier: { blob, ext: 'pdf' }, apercu: pp[0].dataUrl, alerte });
  });

// ---------- import de fichiers (PDF ou images) ----------
async function traiterFichiers(files) {
  for (const [i, f] of files.entries()) {
    const titre = files.length > 1 ? `Justificatif ${i + 1} / ${files.length}` : undefined;
    if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) {
      if (f.size > 30 * 1024 * 1024) {
        toast(`${f.name} est trop volumineux (30 Mo maximum).`, true);
        continue;
      }
      const b64 = await blobToBase64(f);
      const { dep, alerte } = await lire({ pdf: b64 });
      await ouvrirDepense(dep, { fichier: { blob: new Blob([f], { type: 'application/pdf' }), ext: 'pdf' }, alerte, titre });
    } else if (f.type.startsWith('image/')) {
      attente('Préparation de l\'image…');
      const p = await photoToJpeg(f);
      const { dep, alerte } = await lire({ images: [p.base64] });
      await ouvrirDepense(dep, { fichier: { blob: jpegsToPdf([p]), ext: 'pdf' }, apercu: p.dataUrl, alerte, titre });
    }
  }
}
$('#in-fichier').onchange = (e) =>
  protege(async () => {
    const files = [...e.target.files];
    e.target.value = '';
    await traiterFichiers(files);
  });

// Fichiers partagés depuis une autre appli Android (Gmail, Fichiers…)
async function recupererPartage() {
  if (!new URLSearchParams(location.search).has('partage')) return;
  history.replaceState(null, '', location.pathname);
  const c = await caches.open('ndf-partage');
  const keys = await c.keys();
  const files = [];
  for (const k of keys) {
    const r = await c.match(k);
    const blob = await r.blob();
    const name = decodeURIComponent(r.headers.get('X-Nom') || 'justificatif');
    files.push(new File([blob], name, { type: blob.type }));
    await c.delete(k);
  }
  if (files.length) await traiterFichiers(files);
}

// ---------- saisie sans justificatif ----------
$('#btn-manuel').onclick = () => $('#dlg-manuel').showModal();
$('#manuel-annuler').onclick = () => $('#dlg-manuel').close();
$('#manuel-autre').onclick = () =>
  protege(async () => {
    $('#dlg-manuel').close();
    await ouvrirDepense({ categorie: 'divers', date: aujourdhui() }, { titre: 'Dépense sans justificatif' });
  });
const formKm = $('#form-km');
function majKm() {
  const km = num(formKm.km.value);
  const t = num(formKm.taux.value);
  const n = formKm.ar.checked ? 2 : 1;
  $('#km-total').textContent = km && t ? `${n} × ${km} km × ${String(t).replace('.', ',')} € = ${euros(n * km * t)}` : '';
}
formKm.oninput = majKm;
$('#manuel-km').onclick = () =>
  protege(async () => {
    $('#dlg-manuel').close();
    formKm.reset();
    formKm.date.value = aujourdhui();
    formKm.taux.value = String(store.reglages().tauxKm).replace('.', ',');
    formKm.ar.checked = true;
    await remplirAffectation(formKm.affectation, formKm.date.value);
    formKm.date.onchange = () => remplirAffectation(formKm.affectation, formKm.date.value);
    majKm();
    $('#dlg-km').showModal();
  });
$('#km-annuler').onclick = () => $('#dlg-km').close();
formKm.onsubmit = (ev) => {
  ev.preventDefault();
  protege(async () => {
    const km = num(formKm.km.value);
    const t = num(formKm.taux.value);
    const n = formKm.ar.checked ? 2 : 1;
    if (!km || !t) throw new Error('Indique la distance et le barème.');
    const dep = {
      id: store.nouvelId(),
      cree: Date.now(),
      date: formKm.date.value,
      categorie: 'divers',
      fournisseur: 'Déplacement',
      objet: `${formKm.objet.value.trim()} (${n > 1 ? '2 × ' : ''}${km} km × ${String(t).replace('.', ',')} €)`,
      ttc: Math.round(n * km * t * 100) / 100,
      tva: 0,
      invite: '',
      fichier: null,
    };
    dep.nature = store.nature(dep);
    const mois = formKm.affectation.value;
    attente('Enregistrement…');
    const cible = await store.chargerMois(mois);
    cible.depenses.push(dep);
    await store.sauverMois(cible);
    attente(null);
    $('#dlg-km').close();
    moisAffiche = mois;
    await afficherMois();
    toast('Frais kilométriques enregistrés');
  });
};

// ---------- Excel et clôture ----------
async function chargerModele() {
  // Un modèle déposé dans OneDrive (« Notes de frais/modele.xlsx ») est prioritaire
  try {
    return await (await graph.downloadFile(`${store.reglages().racine}/modele.xlsx`)).arrayBuffer();
  } catch {
    return await (await fetch(new URL('modele.xlsx', location.origin + import.meta.env.BASE_URL))).arrayBuffer();
  }
}
const nomBase = (mois) => {
  const r = store.reglages();
  return `NDF ${r.nom} ${store.libelleMois(mois)}`;
};
async function genererExcel(d, dateSignature) {
  const r = store.reglages();
  const bytes = await remplirModele(await chargerModele(), {
    mois: d.mois,
    societe: r.societe,
    nom: r.nom,
    prenom: r.prenom,
    dateSignature,
    depenses: d.depenses,
  });
  return new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}
function telecharger(blob, nom) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = nom;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 10000);
}
$('#btn-excel').onclick = () =>
  protege(async () => {
    attente('Préparation de l\'Excel…');
    const blob = await genererExcel(donnees, donnees.clos_le?.slice(0, 10) || aujourdhui());
    attente(null);
    telecharger(blob, `${nomBase(donnees.mois)}.xlsx`);
  });

$('#btn-cloturer').onclick = () =>
  protege(async () => {
    const r = store.reglages();
    const deps = donnees.depenses;
    if (!deps.length) throw new Error('Aucune dépense à envoyer pour ce mois.');
    const sansJustif = deps.filter((d) => !d.fichier).length;
    $('#clo-mois').textContent = store.libelleMois(donnees.mois);
    $('#clo-recap').innerHTML = `<p><strong>${deps.length}</strong> dépenses, total <strong>${euros(deps.reduce((s, d) => s + d.ttc, 0))}</strong>${
      sansJustif ? `, dont ${sansJustif} sans justificatif` : ''
    }.</p>${donnees.mois === store.moisCourant() ? '<p class="alerte">Attention : le mois n\'est pas terminé.</p>' : ''}`;
    $('#clo-dest').value = r.comptable;
    $('#clo-copie').checked = r.copieMoi;
    $('#clo-progression').hidden = true;
    $('#clo-ok').disabled = false;
    $('#dlg-cloture').showModal();
  });
$('#clo-annuler').onclick = () => $('#dlg-cloture').close();
$('#clo-ok').onclick = () =>
  protege(async () => {
    const dest = $('#clo-dest').value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(dest)) throw new Error('Adresse du destinataire invalide.');
    const r = store.reglages();
    r.comptable = dest;
    r.copieMoi = $('#clo-copie').checked;
    store.enregistrerReglages(r);
    $('#clo-ok').disabled = true;
    const prog = $('#clo-progression');
    prog.hidden = false;
    const etape = (t) => (prog.textContent = t);
    try {
      const d = await store.chargerMois(donnees.mois, true);
      const dossier = store.dossierMois(d.mois);
      const deps = trierDepenses(d.depenses);
      const zip = new JSZip();
      let n = 0;
      for (const [i, dep] of deps.entries()) {
        if (!dep.fichier) continue;
        etape(`Récupération des justificatifs… ${++n}`);
        const blob = await graph.downloadFile(`${dossier}/${dep.fichier}`);
        const ext = dep.fichier.split('.').pop();
        zip.file(`${String(i + 1).padStart(2, '0')} - ${dep.date} - ${store.slug(dep.nature)}.${ext}`, blob);
      }
      etape('Création de l\'Excel…');
      const dateSig = aujourdhui();
      const xlsx = await genererExcel(d, dateSig);
      const base = nomBase(d.mois);
      etape('Création du zip…');
      const zipBlob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
      etape('Copie dans OneDrive…');
      await graph.uploadFile(`${dossier}/${base}.xlsx`, xlsx, xlsx.type);
      await graph.uploadFile(`${dossier}/Justificatifs ${base}.zip`, zipBlob, 'application/zip');
      etape('Envoi du mail…');
      const total = euros(deps.reduce((s, x) => s + x.ttc, 0));
      const qui = `${r.prenom} ${r.nom}`;
      await graph.sendMail({
        to: [dest],
        cc: r.copieMoi ? [getAccount()?.username] : [],
        subject: `Note de frais ${qui} – ${store.libelleMois(d.mois)}`,
        html: `<p>Bonjour,</p><p>Voici ma note de frais de ${store.libelleMois(d.mois).toLowerCase()} : ${deps.length} dépenses pour un total de ${total} TTC.</p><p>Vous trouverez en pièces jointes le tableau Excel et les justificatifs classés par date (numérotés comme les lignes du tableau).</p><p>Bien cordialement,<br>${qui}</p>`,
        attachments: [
          { name: `${base}.xlsx`, blob: xlsx, type: xlsx.type },
          { name: `Justificatifs ${base}.zip`, blob: zipBlob, type: 'application/zip' },
        ],
      });
      d.statut = 'clos';
      d.clos_le = new Date().toISOString();
      d.envoye_a = dest;
      await store.sauverMois(d);
      donnees = d;
      $('#dlg-cloture').close();
      rendreListe();
      toast(`${store.libelleMois(d.mois)} envoyé à ${dest}`);
    } finally {
      $('#clo-ok').disabled = false;
    }
  });
$('#btn-rouvrir').onclick = () =>
  protege(async () => {
    if (!confirm('Rouvrir ce mois pour le modifier ? Il faudra le renvoyer ensuite.')) return;
    donnees.statut = 'ouvert';
    attente('Enregistrement…');
    await store.sauverMois(donnees);
    attente(null);
    rendreListe();
  });

// ---------- navigation et réglages ----------
$('#mois-prec').onclick = () => protege(() => ((moisAffiche = store.decalerMois(moisAffiche, -1)), afficherMois()));
$('#mois-suiv').onclick = () => protege(() => ((moisAffiche = store.decalerMois(moisAffiche, 1)), afficherMois()));
const formReg = $('#form-reglages');
$('#btn-reglages').onclick = () => {
  const r = store.reglages();
  for (const k of ['prenom', 'nom', 'societe', 'comptable', 'racine', 'apiKey', 'model']) formReg[k].value = r[k] ?? '';
  formReg.tauxKm.value = String(r.tauxKm).replace('.', ',');
  $('#reg-compte').textContent = getAccount() ? `Connecté : ${getAccount().username}` : 'Non connecté';
  $('#dlg-reglages').showModal();
};
formReg.onsubmit = (ev) => {
  ev.preventDefault();
  const r = store.reglages();
  for (const k of ['prenom', 'nom', 'societe', 'comptable', 'racine', 'apiKey', 'model']) r[k] = formReg[k].value.trim();
  r.tauxKm = num(formReg.tauxKm.value) || 0.18;
  store.enregistrerReglages(r);
  store.viderCache();
  $('#dlg-reglages').close();
  if (getAccount()) protege(() => afficherMois(true));
  toast('Réglages enregistrés');
};
$('#reg-deconnexion').onclick = () => logout();
$('#btn-connexion').onclick = () => login();

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && getAccount() && !document.querySelector('dialog[open]')) {
    protege(() => afficherMois(true));
  }
});

// ---------- démarrage ----------
if ('serviceWorker' in navigator) navigator.serviceWorker.register(new URL('sw.js', location.origin + import.meta.env.BASE_URL));

protege(async () => {
  const compte = await initAuth();
  if (!compte) {
    $('#ecran-connexion').hidden = false;
    return;
  }
  $('#ecran-mois').hidden = false;
  $('#barre').hidden = false;
  await afficherMois();
  await recupererPartage();
});
