// Photos → JPEG compressés → PDF
import { jsPDF } from 'jspdf';

const MAX = 2000; // plus grand côté, en pixels

export async function photoToJpeg(file) {
  const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
  const k = Math.min(1, MAX / Math.max(bmp.width, bmp.height));
  const w = Math.round(bmp.width * k);
  const h = Math.round(bmp.height * k);
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  // Léger renforcement du contraste pour les tickets
  ctx.filter = 'contrast(1.15) brightness(1.05)';
  ctx.drawImage(bmp, 0, 0, w, h);
  bmp.close?.();
  const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
  return { dataUrl, base64: dataUrl.split(',')[1], w, h };
}

/** Assemble les pages (JPEG) en un PDF, chaque page au format A4 proportionné. */
export function jpegsToPdf(pages) {
  let doc;
  for (const p of pages) {
    const portrait = p.h >= p.w;
    const pw = portrait ? 210 : 297;
    const ph = (p.h / p.w) * pw;
    if (!doc) doc = new jsPDF({ unit: 'mm', format: [pw, ph], orientation: portrait ? 'p' : 'l', compress: true });
    else doc.addPage([pw, ph], portrait ? 'p' : 'l');
    doc.addImage(p.dataUrl, 'JPEG', 0, 0, pw, ph, undefined, 'FAST');
  }
  return doc.output('blob');
}

export function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1]);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}
