// Lecture des justificatifs par l'API Claude
import { CATEGORIES } from './excel.js';

const OUTIL = {
  name: 'enregistrer_depense',
  description: 'Enregistre la dépense lue sur le justificatif.',
  input_schema: {
    type: 'object',
    properties: {
      date: { type: 'string', description: 'Date de la dépense (date de la prestation ou du paiement), format AAAA-MM-JJ.' },
      fournisseur: { type: 'string', description: "Nom commercial court du fournisseur (ex. « SNCF », « Ibis Toulouse », « G7 », « Le Procope »)." },
      objet: { type: 'string', description: "Objet en quelques mots (ex. « Paris-Lyon aller-retour », « nuit du 8 au 9 », « déjeuner »). Chaîne vide si évident." },
      montant_ttc: { type: 'number', description: 'Montant total TTC payé.' },
      montant_tva: { type: 'number', description: 'Montant total de TVA (somme de tous les taux). 0 si non indiqué ou non applicable.' },
      devise: { type: 'string', description: 'Code ISO de la devise (EUR, GBP, USD…).' },
      categorie: { type: 'string', enum: Object.keys(CATEGORIES) },
      nb_couverts: { type: 'integer', description: 'Nombre de couverts pour un restaurant, sinon 0.' },
      remarque: { type: 'string', description: 'Doute éventuel (montant illisible, plusieurs factures sur le document…). Chaîne vide sinon.' },
    },
    required: ['date', 'fournisseur', 'objet', 'montant_ttc', 'montant_tva', 'devise', 'categorie', 'remarque'],
  },
};

const CONSIGNE = `Tu lis un justificatif de dépense professionnelle (ticket, facture, billet) pour une note de frais française.
Catégories :
- restaurant : cafés, restaurants, repas
- taxi : taxis, VTC (Uber, G7, Bolt…)
- sncf : trains (SNCF, Eurostar, Trenitalia, Ouigo…)
- avion : billets d'avion
- ratp : métro, bus, RER, tram, Navigo, tickets de transport en commun
- hotel : hôtels, hébergements, taxes de séjour
- parking : parkings
- divers : péages, carburant, fournitures et tout le reste
Pour le montant TTC, prends le total réellement payé. Pour la TVA, additionne les montants de TVA indiqués (pas les taux). Si la TVA n'apparaît pas, mets 0.
Appelle l'outil enregistrer_depense.`;

/**
 * @param {{images?: string[], pdf?: string}} source  base64 sans préfixe (JPEG ou PDF)
 */
export async function lireJustificatif(source, { apiKey, model }) {
  if (!apiKey) throw new Error('Ajoute ta clé API Claude dans les réglages pour la lecture automatique.');
  const content = [];
  if (source.pdf) {
    content.push({ type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: source.pdf } });
  }
  for (const img of source.images || []) {
    content.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: img } });
  }
  content.push({ type: 'text', text: CONSIGNE });

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: model || 'claude-haiku-4-5',
      max_tokens: 1024,
      tools: [OUTIL],
      tool_choice: { type: 'tool', name: OUTIL.name },
      messages: [{ role: 'user', content }],
    }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = j.error?.message || res.status;
    if (res.status === 401) throw new Error('Clé API Claude refusée : vérifie-la dans les réglages.');
    throw new Error(`Lecture automatique impossible (${msg}).`);
  }
  const bloc = (j.content || []).find((b) => b.type === 'tool_use');
  if (!bloc) throw new Error('Lecture automatique : réponse inattendue.');
  return bloc.input;
}
