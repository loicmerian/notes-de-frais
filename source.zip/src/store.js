// Données de l'appli : réglages (sur le téléphone) et mois (dans OneDrive)
import * as graph from './graph.js';

export const MOIS_NOMS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const DONNEES = '_ndf-donnees.json';

const DEFAUTS = {
  societe: 'Elidia',
  nom: 'Merian',
  prenom: 'Loïc',
  comptable: 'thierry.frigeri@elidia.fr',
  copieMoi: true,
  apiKey: '',
  model: 'claude-haiku-4-5',
  racine: 'Notes de frais',
  tauxKm: 0.18,
};

export function reglages() {
  try {
    return { ...DEFAUTS, ...JSON.parse(localStorage.getItem('ndf-reglages') || '{}') };
  } catch {
    return { ...DEFAUTS };
  }
}
export function enregistrerReglages(r) {
  localStorage.setItem('ndf-reglages', JSON.stringify(r));
}

export const moisCourant = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};
export function decalerMois(mois, n) {
  const [y, m] = mois.split('-').map(Number);
  const d = new Date(y, m - 1 + n, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
export function libelleMois(mois) {
  const [y, m] = mois.split('-').map(Number);
  return `${MOIS_NOMS[m - 1]} ${y}`;
}
export function dossierMois(mois) {
  const [y, m] = mois.split('-');
  return `${reglages().racine}/${y}/${m} ${MOIS_NOMS[Number(m) - 1]} ${y}`;
}

const cache = new Map();

export async function chargerMois(mois, force = false) {
  if (!force && cache.has(mois)) return cache.get(mois);
  const data = (await graph.getJson(`${dossierMois(mois)}/${DONNEES}`)) || { mois, statut: 'ouvert', depenses: [] };
  cache.set(mois, data);
  return data;
}

export async function sauverMois(data) {
  data.modifie = new Date().toISOString();
  cache.set(data.mois, data);
  await graph.putJson(`${dossierMois(data.mois)}/${DONNEES}`, data);
}

export const viderCache = () => cache.clear();

export function slug(s) {
  return (
    String(s || 'justificatif')
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^\w\s-]/g, ' ')
      .trim()
      .replace(/\s+/g, ' ')
      .slice(0, 50) || 'justificatif'
  );
}

export function nomJustificatif(dep, ext = 'pdf') {
  return `${dep.date} - ${slug(dep.fournisseur)}${dep.objet ? ' - ' + slug(dep.objet) : ''} (${dep.id.slice(0, 4)}).${ext}`;
}

export function nature(dep) {
  return [dep.fournisseur, dep.objet].filter(Boolean).join(' - ');
}

export const nouvelId = () =>
  (crypto.randomUUID?.() || Math.random().toString(36).slice(2) + Date.now().toString(36)).replace(/-/g, '');
