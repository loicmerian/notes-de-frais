// Données de l'appli : réglages (sur le téléphone) et mois (dans OneDrive)
import * as graph from './graph.js';

export const MOIS_NOMS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const DONNEES = '_ndf-donnees.json';

const DEFAUTS = {
  societe: 'Elidia',
  nom: 'Merian',
  prenom: 'Loïc',
  comptable: 'thierry.frigeri@elidia.fr',
  copieMoi: true,
  apiKey: '',
  model: 'claude-haiku-4-5',
  racine: 'Notes de frais',
  tauxKm: 0.18,
};

export function reglages() {
  try {
    return { ...DEFAUTS, ...JSON.parse(localStorage.getItem('ndf-reglages') || '{}') };
  } catch {
    return { ...DEFAUTS };
  }
}
export function enregistrerReglages(r) {
  localStorage.setItem('ndf-reglages', JSON.stringify(r));
}

export const moisCourant = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};
export function decalerMois(mois, n) {
  const [y, m] = mois.split('-').map(Number);
  const d = new Date(y, m - 1 + n, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
export function libelleMois(mois) {
  const [y, m] = mois.split('-').map(Number);
  return `${MOIS_NOMS[m - 1]} ${y}`;
}
export function dossierMois(mois) {
  const [y, m] = mois.split('-');
  return `${reglages().racine}/${y}/${m} ${MOIS_NOMS[Number(m) - 1]} ${y}`;
}

const cache = new Map();

/**
 * Fusionne deux versions d'un mois (locale et OneDrive) sans rien perdre :
 * union des dépenses par identifiant, la plus récente l'emporte, les suppressions sont conservées.
 */
function fusion(a, b) {
  if (!a) return b;
  if (!b) return a;
  const [recent, ancien] = (a.modifie || '') >= (b.modifie || '') ? [a, b] : [b, a];
  const supprimes = [...new Set([...(a.supprimes || []), ...(b.supprimes || [])])];
  const parId = new Map();
  for (const d of [...ancien.depenses, ...recent.depenses]) {
    const prec = parId.get(d.id);
    if (!prec || (d.maj || d.cree || 0) >= (prec.maj || prec.cree || 0)) parId.set(d.id, d);
  }
  return {
    ...recent,
    supprimes,
    depenses: [...parId.values()].filter((d) => !supprimes.includes(d.id)),
  };
}

/** Remplace le contenu d'un objet mois en gardant la même référence. */
function remplacer(cible, source) {
  if (cible === source) return cible;
  source = { ...source };
  for (const k of Object.keys(cible)) delete cible[k];
  Object.assign(cible, source);
  return cible;
}

export async function chargerMois(mois, force = false) {
  const local = cache.get(mois);
  if (!force && local) return local;
  const distant = await graph.getJson(`${dossierMois(mois)}/${DONNEES}`);
  const fusionne = fusion(local, distant) || { mois, statut: 'ouvert', depenses: [], supprimes: [] };
  if (local) return remplacer(local, fusionne);
  cache.set(mois, fusionne);
  return fusionne;
}

export async function sauverMois(data) {
  data.modifie = new Date().toISOString();
  // Relire OneDrive juste avant d'écrire, pour ne jamais écraser une dépense
  const distant = await graph.getJson(`${dossierMois(data.mois)}/${DONNEES}`);
  remplacer(data, fusion(data, distant));
  data.modifie = new Date().toISOString();
  cache.set(data.mois, data);
  await graph.putJson(`${dossierMois(data.mois)}/${DONNEES}`, data);
  return data;
}

export const viderCache = () => cache.clear();

export function slug(s) {
  return (
    String(s || 'justificatif')
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^\w\s-]/g, ' ')
      .trim()
      .replace(/\s+/g, ' ')
      .slice(0, 50) || 'justificatif'
  );
}

export function nomJustificatif(dep, ext = 'pdf') {
  return `${dep.date} - ${slug(dep.fournisseur)}${dep.objet ? ' - ' + slug(dep.objet) : ''} (${dep.id.slice(0, 4)}).${ext}`;
}

export function nature(dep) {
  return [dep.fournisseur, dep.objet].filter(Boolean).join(' - ');
}

export const nouvelId = () =>
  (crypto.randomUUID?.() || Math.random().toString(36).slice(2) + Date.now().toString(36)).replace(/-/g, '');
