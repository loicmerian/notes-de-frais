// Remplit le modèle Excel « Note de frais Elidia » en modifiant directement le XML
// de la feuille, pour garder intacts la mise en forme, l'image et le graphique.
import JSZip from 'jszip';

export const CATEGORIES = {
  restaurant: { label: 'Café / restaurant', col: 'E', ht: true, invite: 'F' },
  taxi: { label: 'Taxi / VTC', col: 'G', ht: true, invite: 'H' },
  sncf: { label: 'Train (SNCF, Eurostar…)', col: 'I', ht: false },
  avion: { label: 'Avion', col: 'J', ht: false },
  ratp: { label: 'RATP / transports en commun', col: 'K', ht: false },
  hotel: { label: 'Hôtel / taxe de séjour', col: 'L', ht: false },
  parking: { label: 'Parking', col: 'M', ht: true },
  divers: { label: 'Divers (péages, km, autres)', col: 'N', ht: true },
};

const COLS = 'ABCDEFGHIJKLMN'.split('');
const FIRST_ROW = 11;
const LAST_ROW = 50;
const DEFAULT_STYLE = { A: 18, B: 25, F: 23, H: 23 }; // les autres colonnes : 22

const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

export function excelSerial(isoDate) {
  const [y, m, d] = isoDate.split('-').map(Number);
  return Math.round((Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 86400000);
}

const esc = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function cellXml(ref, style, value) {
  const s = style != null ? ` s="${style}"` : '';
  if (value === null || value === undefined || value === '') return `<c r="${ref}"${s}/>`;
  if (typeof value === 'number') return `<c r="${ref}"${s}><v>${value}</v></c>`;
  if (typeof value === 'object' && value.f) {
    return `<c r="${ref}"${s}><f>${esc(value.f)}</f><v>${value.v}</v></c>`;
  }
  return `<c r="${ref}"${s} t="inlineStr"><is><t xml:space="preserve">${esc(value)}</t></is></c>`;
}

function getStyle(xml, ref) {
  const m = xml.match(new RegExp(`<c r="${ref}"[^>]*?\\ss="(\\d+)"`));
  return m ? Number(m[1]) : null;
}

function replaceCell(xml, ref, value) {
  const style = getStyle(xml, ref);
  const re = new RegExp(`<c r="${ref}"(?:\\s[^>]*?)?(?:/>|>[\\s\\S]*?</c>)`);
  if (!re.test(xml)) throw new Error(`Cellule ${ref} introuvable dans le modèle`);
  return xml.replace(re, cellXml(ref, style, value));
}

function replaceRowCells(xml, rowNum, values) {
  const re = new RegExp(`(<row r="${rowNum}"[^>]*>)([\\s\\S]*?)(</row>)`);
  const m = xml.match(re);
  if (!m) throw new Error(`Ligne ${rowNum} introuvable dans le modèle`);
  const cells = COLS.map((c) => {
    const ref = `${c}${rowNum}`;
    const style = getStyle(m[2], ref) ?? DEFAULT_STYLE[c] ?? 22;
    return cellXml(ref, style, values[c]);
  }).join('');
  return xml.replace(re, `$1${cells}$3`);
}

/** Transforme une dépense en valeurs de colonnes A..N. */
export function depenseToRow(d) {
  const cat = CATEGORIES[d.categorie] || CATEGORIES.divers;
  const ttc = round2(d.ttc);
  const tva = round2(d.tva);
  const row = {
    A: excelSerial(d.date),
    B: d.nature || '',
    C: ttc,
    D: tva ? tva : null,
  };
  row[cat.col] = cat.ht ? round2(ttc - tva) : ttc;
  if (cat.invite && d.invite) row[cat.invite] = d.invite;
  return row;
}

export function trierDepenses(depenses) {
  return [...depenses].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.cree || 0) - (b.cree || 0)));
}

/**
 * @param {ArrayBuffer|Uint8Array} modele  le fichier modèle .xlsx
 * @param {{mois:string, societe:string, nom:string, prenom:string, dateSignature:string, depenses:Array}} data
 * @returns {Promise<Uint8Array>}
 */
export async function remplirModele(modele, data) {
  const lignes = trierDepenses(data.depenses).map(depenseToRow);
  const capacite = LAST_ROW - FIRST_ROW + 1;
  if (lignes.length > capacite) {
    throw new Error(`Le modèle contient ${capacite} lignes, mais le mois a ${lignes.length} dépenses.`);
  }

  const zip = await JSZip.loadAsync(modele);
  const wbRels = await zip.file('xl/_rels/workbook.xml.rels').async('string');
  const wb = await zip.file('xl/workbook.xml').async('string');
  // Trouver la feuille « Note de frais » (pas le graphique)
  const sheetMatch = [...wb.matchAll(/<sheet [^>]*name="([^"]+)"[^>]*r:id="([^"]+)"/g)].find((m) => /frais/i.test(m[1]));
  const rid = sheetMatch ? sheetMatch[2] : null;
  const target = rid && wbRels.match(new RegExp(`Id="${rid}"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Id="${rid}"`));
  const sheetPath = 'xl/' + ((target && (target[1] || target[2])) || 'worksheets/sheet1.xml').replace(/^\/?xl\//, '');
  let xml = await zip.file(sheetPath).async('string');

  // En-tête
  xml = replaceCell(xml, 'B2', excelSerial(data.mois + '-01'));
  xml = replaceCell(xml, 'B3', data.societe);
  xml = replaceCell(xml, 'B4', data.nom);
  xml = replaceCell(xml, 'B5', data.prenom);

  // Lignes de dépenses
  const totaux = {};
  for (let r = FIRST_ROW; r <= LAST_ROW; r++) {
    const v = lignes[r - FIRST_ROW] || {};
    for (const c of 'CDEGIJKLMN') if (typeof v[c] === 'number') totaux[c] = round2((totaux[c] || 0) + v[c]);
    xml = replaceRowCells(xml, r, v);
  }

  // Totaux (formules + valeurs calculées)
  const total = {};
  for (const c of 'CDEGIJKLMN') total[c] = { f: `SUM(${c}${FIRST_ROW}:${c}${LAST_ROW})`, v: totaux[c] || 0 };
  const re51 = /(<row r="51"[^>]*>)([\s\S]*?)(<\/row>)/;
  const row51 = xml.match(re51)[2];
  const cells51 = COLS.map((c) => {
    const ref = `${c}51`;
    const style = getStyle(row51, ref);
    if (total[c]) return cellXml(ref, style, total[c]);
    const existing = row51.match(new RegExp(`<c r="${ref}"(?:\\s[^>]*?)?(?:/>|>[\\s\\S]*?</c>)`));
    return existing ? existing[0] : '';
  }).join('');
  xml = xml.replace(re51, `$1${cells51}$3`);

  // Date de signature
  xml = replaceCell(xml, 'C54', excelSerial(data.dateSignature));
  // Sélection sur A1, pour éviter une cellule active hors du tableau
  xml = xml.replace(/<selection [^>]*\/>/, '<selection activeCell="A11" sqref="A11"/>');
  zip.file(sheetPath, xml);

  // Forcer le recalcul complet à l'ouverture et supprimer la chaîne de calcul obsolète
  zip.file(
    'xl/workbook.xml',
    wb.replace(/<calcPr([^>]*?)\/>/, (m, a) => `<calcPr${a.replace(/\sfullCalcOnLoad="[^"]*"/, '')} fullCalcOnLoad="1"/>`)
  );
  if (zip.file('xl/calcChain.xml')) {
    zip.remove('xl/calcChain.xml');
    zip.file('xl/_rels/workbook.xml.rels', wbRels.replace(/<Relationship [^>]*calcChain[^>]*\/>/, ''));
    const ct = await zip.file('[Content_Types].xml').async('string');
    zip.file('[Content_Types].xml', ct.replace(/<Override [^>]*calcChain[^>]*\/>/, ''));
  }

  return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE' });
}
