// Accès à OneDrive et Outlook via Microsoft Graph
import { getToken } from './auth.js';

const G = 'https://graph.microsoft.com/v1.0';
const CHUNK = 320 * 1024 * 10; // 3,2 Mo, multiple de 320 Kio

async function gfetch(url, opts = {}, retry = 2) {
  const token = await getToken();
  const res = await fetch(url.startsWith('http') ? url : G + url, {
    ...opts,
    headers: { Authorization: `Bearer ${token}`, ...(opts.headers || {}) },
  });
  if ((res.status === 429 || res.status >= 500) && retry > 0) {
    const wait = Number(res.headers.get('Retry-After') || 2) * 1000;
    await new Promise((r) => setTimeout(r, wait));
    return gfetch(url, opts, retry - 1);
  }
  if (!res.ok) {
    let msg = `${res.status}`;
    try {
      const j = await res.json();
      msg = j.error?.message || msg;
    } catch {}
    const err = new Error(`Microsoft 365 : ${msg}`);
    err.status = res.status;
    throw err;
  }
  return res;
}

const encPath = (p) => p.split('/').map(encodeURIComponent).join('/');
const itemUrl = (path) => `/me/drive/root:/${encPath(path)}:`;

export async function getJson(path) {
  try {
    const meta = await (await gfetch(`${itemUrl(path)}?select=id,@microsoft.graph.downloadUrl`)).json();
    const r = await fetch(meta['@microsoft.graph.downloadUrl']);
    return await r.json();
  } catch (e) {
    if (e.status === 404) return null;
    throw e;
  }
}

export async function downloadFile(path) {
  const meta = await (await gfetch(`${itemUrl(path)}?select=id,@microsoft.graph.downloadUrl`)).json();
  const r = await fetch(meta['@microsoft.graph.downloadUrl']);
  if (!r.ok) throw new Error(`Téléchargement impossible : ${path}`);
  return r.blob();
}

export async function getWebUrl(path) {
  const meta = await (await gfetch(`${itemUrl(path)}?select=webUrl`)).json();
  return meta.webUrl;
}

/** Envoie un fichier dans OneDrive (les dossiers parents sont créés au besoin). */
export async function uploadFile(path, blob, contentType = 'application/octet-stream') {
  if (!(blob instanceof Blob)) blob = new Blob([blob], { type: contentType });
  if (blob.size < 4 * 1024 * 1024) {
    const r = await gfetch(`${itemUrl(path)}/content?@microsoft.graph.conflictBehavior=replace`, {
      method: 'PUT',
      headers: { 'Content-Type': contentType },
      body: blob,
    });
    return r.json();
  }
  const s = await (
    await gfetch(`${itemUrl(path)}/createUploadSession`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item: { '@microsoft.graph.conflictBehavior': 'replace' } }),
    })
  ).json();
  let last;
  for (let start = 0; start < blob.size; start += CHUNK) {
    const end = Math.min(start + CHUNK, blob.size);
    last = await fetch(s.uploadUrl, {
      method: 'PUT',
      headers: { 'Content-Range': `bytes ${start}-${end - 1}/${blob.size}` },
      body: blob.slice(start, end),
    });
    if (!last.ok && last.status !== 202) throw new Error(`Envoi interrompu (${last.status})`);
  }
  return last.json();
}

export async function putJson(path, data) {
  return uploadFile(path, new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), 'application/json');
}

export async function deleteFile(path) {
  try {
    await gfetch(itemUrl(path), { method: 'DELETE' });
  } catch (e) {
    if (e.status !== 404) throw e;
  }
}

export async function listChildren(path) {
  try {
    const r = await (await gfetch(`${itemUrl(path)}/children?select=name,folder,file&$top=999`)).json();
    return r.value || [];
  } catch (e) {
    if (e.status === 404) return [];
    throw e;
  }
}

export async function me() {
  return (await gfetch('/me?select=displayName,givenName,surname,mail,userPrincipalName')).json();
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

/**
 * Envoie un mail depuis la boîte de l'utilisateur, avec pièces jointes de toute taille (jusqu'à 150 Mo).
 * @param {{to:string[], cc?:string[], subject:string, html:string, attachments:{name:string, blob:Blob, type:string}[]}} m
 */
export async function sendMail({ to, cc = [], subject, html, attachments = [] }) {
  const rcpt = (list) => list.filter(Boolean).map((address) => ({ emailAddress: { address } }));
  const draft = await (
    await gfetch('/me/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject,
        body: { contentType: 'HTML', content: html },
        toRecipients: rcpt(to),
        ccRecipients: rcpt(cc),
      }),
    })
  ).json();

  for (const a of attachments) {
    if (a.blob.size < 3 * 1024 * 1024) {
      await gfetch(`/me/messages/${draft.id}/attachments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          '@odata.type': '#microsoft.graph.fileAttachment',
          name: a.name,
          contentType: a.type,
          contentBytes: toBase64(await a.blob.arrayBuffer()),
        }),
      });
    } else {
      const s = await (
        await gfetch(`/me/messages/${draft.id}/attachments/createUploadSession`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ AttachmentItem: { attachmentType: 'file', name: a.name, size: a.blob.size, contentType: a.type } }),
        })
      ).json();
      const size = a.blob.size;
      for (let start = 0; start < size; start += CHUNK) {
        const end = Math.min(start + CHUNK, size);
        const r = await fetch(s.uploadUrl, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/octet-stream', 'Content-Range': `bytes ${start}-${end - 1}/${size}` },
          body: a.blob.slice(start, end),
        });
        if (!r.ok) throw new Error(`Pièce jointe ${a.name} : envoi interrompu (${r.status})`);
      }
    }
  }
  await gfetch(`/me/messages/${draft.id}/send`, { method: 'POST' });
}
